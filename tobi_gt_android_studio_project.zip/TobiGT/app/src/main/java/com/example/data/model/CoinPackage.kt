package com.example.data.model

data class CoinPackage(
    val productId: String,
    val priceDollars: Double,
    val diamondAmount: Long,
    val formattedPrice: String,
    val badge: String? = null,
    val isPopular: Boolean = false,
    val isBestValue: Boolean = false
) {
    // Backward compatibility for existing references
    val coinAmount: Long get() = diamondAmount
}

typealias DiamondPackage = CoinPackage

object CoinPackages {
    val ALL: List<CoinPackage> = listOf(
        CoinPackage("diamonds_51", 0.51, 51L, "$0.51", badge = "MICRO DROP"),
        CoinPackage("diamonds_101", 1.01, 101L, "$1.01", badge = "STARTER"),
        CoinPackage("diamonds_201", 2.01, 201L, "$2.01"),
        CoinPackage("diamonds_301", 3.01, 301L, "$3.01"),
        CoinPackage("diamonds_401", 4.01, 401L, "$4.01"),
        CoinPackage("diamonds_501", 5.01, 501L, "$5.01", badge = "PILOT'S PICK"),
        CoinPackage("diamonds_601", 6.01, 601L, "$6.01"),
        CoinPackage("diamonds_701", 7.01, 701L, "$7.01"),
        CoinPackage("diamonds_801", 8.01, 801L, "$8.01"),
        CoinPackage("diamonds_901", 9.01, 901L, "$9.01"),
        CoinPackage("diamonds_1001", 10.01, 1001L, "$10.01", badge = "POPULAR", isPopular = true),
        CoinPackage("diamonds_1501", 15.01, 1501L, "$15.01"),
        CoinPackage("diamonds_2001", 20.01, 2001L, "$20.01"),
        CoinPackage("diamonds_2501", 25.01, 2501L, "$25.01", badge = "SQUADRON"),
        CoinPackage("diamonds_3001", 30.01, 3001L, "$30.01"),
        CoinPackage("diamonds_4001", 40.01, 4001L, "$40.01"),
        CoinPackage("diamonds_5001", 50.01, 5001L, "$50.01", badge = "WAR CHEST"),
        CoinPackage("diamonds_9901", 99.01, 9901L, "$99.01", badge = "HIGH ROLLER"),
        CoinPackage("diamonds_50001", 500.01, 50001L, "$500.01", badge = "ARMADA"),
        CoinPackage("diamonds_100001", 1000.01, 100001L, "$1,000.01", badge = "SUPREME FLEET", isBestValue = true)
    )

    fun findById(productId: String): CoinPackage? {
        val normalized = productId.replace("coins_", "diamonds_")
            .replace("tobi_coins_", "diamonds_")
            .replace("diamonds_50", "diamonds_51")
        return ALL.find { it.productId == productId || it.productId == normalized }
    }
}

