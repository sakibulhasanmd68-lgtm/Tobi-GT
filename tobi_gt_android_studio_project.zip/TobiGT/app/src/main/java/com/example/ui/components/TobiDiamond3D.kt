package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Premium 3D Faceted Crystal Diamond for Tobi GT.
 * Renders an original 3D crystal gemstone with geometric facets,
 * depth gradients, refractive light caustics, and subtle animated shimmer.
 */
@Composable
fun TobiDiamond3D(
    size: Dp = 48.dp,
    modifier: Modifier = Modifier,
    animated: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "diamond_shimmer")
    val shimmerPhase by if (animated) {
        infiniteTransition.animateFloat(
            initialValue = -0.3f,
            targetValue = 1.3f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 2600, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "shimmer_pos"
        )
    } else {
        rememberInfiniteTransition(label = "static").animateFloat(
            initialValue = 0.5f,
            targetValue = 0.5f,
            animationSpec = infiniteRepeatable(tween(1000)),
            label = "static"
        )
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height

            // Dimensions and key facet vertices
            // Crown top edge: y = 0.14h
            // Girdle: y = 0.42h
            // Culet: y = 0.94h
            val topY = h * 0.14f
            val girdleY = h * 0.42f
            val culetY = h * 0.94f
            val centerX = w * 0.5f

            val tLeftX = w * 0.26f
            val tRightX = w * 0.74f

            val gLeftX = w * 0.08f
            val gRightX = w * 0.92f

            val cLeftX = w * 0.35f
            val cRightX = w * 0.65f

            // 1. Ambient Glow Aura behind crystal
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x6600E5FF),
                        Color(0x220284C7),
                        Color(0x00000000)
                    ),
                    center = Offset(centerX, h * 0.5f),
                    radius = w * 0.55f
                )
            )

            // 2. Lower Pavilion Facets (Tapering to Culet)
            // Pavilion Left Facet
            val pLeft = Path().apply {
                moveTo(gLeftX, girdleY)
                lineTo(cLeftX, girdleY)
                lineTo(centerX, culetY)
                close()
            }
            drawPath(
                path = pLeft,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF0369A1), Color(0xFF075985), Color(0xFF0C4A6E)),
                    start = Offset(gLeftX, girdleY),
                    end = Offset(centerX, culetY)
                )
            )

            // Pavilion Center-Left Facet
            val pCenterLeft = Path().apply {
                moveTo(cLeftX, girdleY)
                lineTo(centerX, girdleY)
                lineTo(centerX, culetY)
                close()
            }
            drawPath(
                path = pCenterLeft,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF0284C7), Color(0xFF0369A1), Color(0xFF0C4A6E)),
                    start = Offset(cLeftX, girdleY),
                    end = Offset(centerX, culetY)
                )
            )

            // Pavilion Center-Right Facet
            val pCenterRight = Path().apply {
                moveTo(centerX, girdleY)
                lineTo(cRightX, girdleY)
                lineTo(centerX, culetY)
                close()
            }
            drawPath(
                path = pCenterRight,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF00B4D8), Color(0xFF0284C7), Color(0xFF075985)),
                    start = Offset(centerX, girdleY),
                    end = Offset(centerX, culetY)
                )
            )

            // Pavilion Right Facet
            val pRight = Path().apply {
                moveTo(cRightX, girdleY)
                lineTo(gRightX, girdleY)
                lineTo(centerX, culetY)
                close()
            }
            drawPath(
                path = pRight,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF38BDF8), Color(0xFF00B4D8), Color(0xFF0369A1)),
                    start = Offset(gRightX, girdleY),
                    end = Offset(centerX, culetY)
                )
            )

            // 3. Crown Upper Facets
            // Crown Left Corner Facet
            val cLeft = Path().apply {
                moveTo(tLeftX, topY)
                lineTo(gLeftX, girdleY)
                lineTo(cLeftX, girdleY)
                close()
            }
            drawPath(
                path = cLeft,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF0284C7), Color(0xFF0369A1), Color(0xFF075985)),
                    start = Offset(tLeftX, topY),
                    end = Offset(gLeftX, girdleY)
                )
            )

            // Crown Center Left Facet
            val cMidLeft = Path().apply {
                moveTo(tLeftX, topY)
                lineTo(centerX, topY)
                lineTo(centerX, girdleY)
                lineTo(cLeftX, girdleY)
                close()
            }
            drawPath(
                path = cMidLeft,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF38BDF8), Color(0xFF00E5FF), Color(0xFF0284C7)),
                    start = Offset(tLeftX, topY),
                    end = Offset(centerX, girdleY)
                )
            )

            // Crown Center Right Facet
            val cMidRight = Path().apply {
                moveTo(centerX, topY)
                lineTo(tRightX, topY)
                lineTo(cRightX, girdleY)
                lineTo(centerX, girdleY)
                close()
            }
            drawPath(
                path = cMidRight,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFFE0F2FE), Color(0xFF7DD3FC), Color(0xFF00B4D8)),
                    start = Offset(centerX, topY),
                    end = Offset(cRightX, girdleY)
                )
            )

            // Crown Right Corner Facet
            val cRight = Path().apply {
                moveTo(tRightX, topY)
                lineTo(cRightX, girdleY)
                lineTo(gRightX, girdleY)
                close()
            }
            drawPath(
                path = cRight,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFFBAE6FD), Color(0xFF38BDF8), Color(0xFF0284C7)),
                    start = Offset(tRightX, topY),
                    end = Offset(gRightX, girdleY)
                )
            )

            // 4. Crown Table Top Facet (Flat Brilliant Octagon/Hexagon Surface)
            val tablePath = Path().apply {
                moveTo(tLeftX, topY)
                lineTo(tRightX, topY)
                lineTo(cRightX, girdleY * 0.82f)
                lineTo(cLeftX, girdleY * 0.82f)
                close()
            }
            drawPath(
                path = tablePath,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFFF0F9FF), Color(0xFFBAE6FD), Color(0xFF00E5FF)),
                    start = Offset(tLeftX, topY),
                    end = Offset(tRightX, girdleY * 0.82f)
                )
            )

            // 5. Dynamic Shimmer Sweep
            val shimmerX = w * shimmerPhase
            val shimmerWidth = w * 0.35f
            val fullDiamondPath = Path().apply {
                moveTo(tLeftX, topY)
                lineTo(tRightX, topY)
                lineTo(gRightX, girdleY)
                lineTo(centerX, culetY)
                lineTo(gLeftX, girdleY)
                close()
            }

            drawPath(
                path = fullDiamondPath,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color(0x11FFFFFF),
                        Color(0x88FFFFFF),
                        Color(0x11FFFFFF),
                        Color.Transparent
                    ),
                    start = Offset(shimmerX - shimmerWidth, topY),
                    end = Offset(shimmerX + shimmerWidth, culetY)
                )
            )

            // 6. Facet Outlines and Girdle Highlight Line
            val strokeColor = Color(0x66FFFFFF)
            val strokeWidth = (w * 0.018f).coerceAtLeast(1f)

            // Outer boundary stroke
            drawPath(
                path = fullDiamondPath,
                color = Color(0xAA00E5FF),
                style = Stroke(width = strokeWidth)
            )

            // Table stroke
            drawPath(
                path = tablePath,
                color = strokeColor,
                style = Stroke(width = strokeWidth * 0.75f)
            )

            // Inner facet lines
            drawLine(
                color = strokeColor,
                start = Offset(cLeftX, girdleY),
                end = Offset(centerX, culetY),
                strokeWidth = strokeWidth * 0.7f
            )
            drawLine(
                color = strokeColor,
                start = Offset(centerX, girdleY),
                end = Offset(centerX, culetY),
                strokeWidth = strokeWidth * 0.7f
            )
            drawLine(
                color = strokeColor,
                start = Offset(cRightX, girdleY),
                end = Offset(centerX, culetY),
                strokeWidth = strokeWidth * 0.7f
            )

            // 7. Twinkle Flare Sparkle on Top-Right Crown
            val sparkleX = tRightX * 0.95f
            val sparkleY = topY * 1.05f
            val sparkleRadius = (w * 0.06f).coerceAtLeast(2f)

            drawCircle(
                color = Color.White,
                radius = sparkleRadius * 0.6f,
                center = Offset(sparkleX, sparkleY)
            )
            drawLine(
                color = Color.White,
                start = Offset(sparkleX - sparkleRadius * 1.6f, sparkleY),
                end = Offset(sparkleX + sparkleRadius * 1.6f, sparkleY),
                strokeWidth = 1.5f
            )
            drawLine(
                color = Color.White,
                start = Offset(sparkleX, sparkleY - sparkleRadius * 1.6f),
                end = Offset(sparkleX, sparkleY + sparkleRadius * 1.6f),
                strokeWidth = 1.5f
            )
        }
    }
}
